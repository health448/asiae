// Voting logic for vote.html (real gift card validation)
if (document.getElementById('vote-form')) {
    const voteForm = document.getElementById('vote-form');
    const voteMessage = document.getElementById('vote-message');
    voteForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        const actor = document.getElementById('actor').value;
        const votes = parseInt(document.getElementById('votes').value, 10);
        const giftcard = document.getElementById('giftcard').value.trim();
        voteMessage.textContent = 'Processing...';
        voteMessage.style.color = '#222';
        try {
            const res = await fetch('http://localhost:3001/api/redeem-giftcard', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ code: giftcard, votes })
            });
            const data = await res.json();
            if (data.success) {
                voteMessage.textContent = 'Payment successful! Your votes have been cast.';
                voteMessage.style.color = 'green';
                voteForm.reset();
            } else {
                voteMessage.textContent = data.message || 'Gift card error.';
                voteMessage.style.color = 'red';
            }
        } catch (err) {
            voteMessage.textContent = 'Server error. Please try again later.';
            voteMessage.style.color = 'red';
        }
    });
}
document.getElementById('membership-form')?.addEventListener('submit', function(e) {
    e.preventDefault();
    document.getElementById('form-message').textContent = 'Thank you for your request! We will contact you soon.';
    this.reset();
});

// Real-time chat logic for chat.html using Socket.IO
if (document.getElementById('chat-form')) {
    const chatForm = document.getElementById('chat-form');
    const chatInput = document.getElementById('chat-input');
    const chatMessages = document.getElementById('chat-messages');
    const celebSelect = document.getElementById('celebrity-select');
    let socket = null;
    let currentCeleb = celebSelect.value;

    function addMessage(text, sender) {
        const msgDiv = document.createElement('div');
        msgDiv.className = 'chat-message ' + sender;
        const bubble = document.createElement('div');
        bubble.className = 'bubble';
        bubble.textContent = text;
        msgDiv.appendChild(bubble);
        chatMessages.appendChild(msgDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function connectSocket(celeb) {
        if (socket) socket.disconnect();
        socket = io('http://localhost:3001');
        socket.on('connect', () => {
            socket.emit('joinRoom', celeb);
        });
        socket.on('message', (msg) => {
            addMessage(msg.text, msg.sender);
        });
    }

    connectSocket(currentCeleb);

    chatForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const userMsg = chatInput.value.trim();
        if (!userMsg) return;
        if (socket && socket.connected) {
            socket.emit('chatMessage', { celeb: currentCeleb, text: userMsg });
        } else {
            addMessage('Connection error. Please refresh the page.', 'celebrity');
        }
        chatInput.value = '';
    });

    celebSelect.addEventListener('change', function() {
        chatMessages.innerHTML = '';
        currentCeleb = celebSelect.value;
        connectSocket(currentCeleb);
    });
}