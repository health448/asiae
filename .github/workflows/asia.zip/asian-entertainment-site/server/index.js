const fs = require('fs');
const path = require('path');

// Helper to load and save gift cards
const giftCardPath = path.join(__dirname, 'giftcards.json');
function loadGiftCards() {
  return JSON.parse(fs.readFileSync(giftCardPath, 'utf-8'));
}
function saveGiftCards(cards) {
  fs.writeFileSync(giftCardPath, JSON.stringify(cards, null, 2));
}

// API to validate and redeem gift card
app.use(express.json());
app.post('/api/redeem-giftcard', (req, res) => {
  const { code, votes } = req.body;
  if (!code || !votes) return res.status(400).json({ success: false, message: 'Missing code or votes.' });
  let cards = loadGiftCards();
  const card = cards.find(c => c.code === code && !c.used);
  if (!card) return res.status(400).json({ success: false, message: 'Invalid or already used gift card.' });
  // Check value matches vote package
  const valueNeeded = votes == 10 ? 50 : votes == 50 ? 100 : votes == 100 ? 200 : 0;
  if (card.value !== valueNeeded) return res.status(400).json({ success: false, message: 'Gift card value does not match vote package.' });
  card.used = true;
  saveGiftCards(cards);
  return res.json({ success: true, message: 'Gift card redeemed. Votes purchased.' });
});
const express = require('express');
const http = require('http');
const cors = require('cors');
const { Server } = require('socket.io');

const app = express();
app.use(cors());

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

// Simulated celebrity bots
const celebBots = {
  kim: [
    "Hello, this is Kim Soo Hyun! How can I make your day better?",
    "Thank you for your support!",
    "I'm always happy to chat with my fans."
  ],
  park: [
    "Hi, Park Hyung Sik here! What would you like to talk about?",
    "Your support means a lot to me!",
    "Let's make great memories together."
  ],
  ahn: [
    "Hey, it's Ahn Hyo Seop! How are you today?",
    "Thanks for being such a wonderful fan!",
    "I'm excited to chat with you!"
  ]
};

const celebNames = {
  kim: "Kim Soo Hyun",
  park: "Park Hyung Sik",
  ahn: "Ahn Hyo Seop"
};

io.on('connection', (socket) => {
  socket.on('joinRoom', (celeb) => {
    socket.join(celeb);
    socket.emit('message', {
      sender: 'celebrity',
      text: `You are now chatting with ${celebNames[celeb]}.`
    });
  });

  socket.on('chatMessage', ({ celeb, text }) => {
    // User message
    io.to(socket.id).emit('message', {
      sender: 'user',
      text
    });
    // Simulate celebrity reply
    setTimeout(() => {
      const replies = celebBots[celeb];
      const reply = replies[Math.floor(Math.random() * replies.length)];
      io.to(socket.id).emit('message', {
        sender: 'celebrity',
        text: `${celebNames[celeb]}: ${reply}`
      });
    }, 900);
  });
});

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
